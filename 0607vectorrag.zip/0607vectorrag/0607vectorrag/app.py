import os
import streamlit as st
from dotenv import load_dotenv
import tempfile
import torchvision


### langchain imports

from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters  import RecursiveCharacterTextSplitter
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_core.prompts import PromptTemplate
from langchain_chroma import Chroma
from langchain_classic.chains import RetrievalQA
## from langchain.chains import RetrievalQA


### load environment variables from .env file. 
load_dotenv()
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")

if not GOOGLE_API_KEY:
    st.error("Google API key is not set. Please set it in the .env file.")
    st.stop()

os.environ["GOOGLE_API_KEY"] = GOOGLE_API_KEY

### LLM Initialization
llm = ChatGoogleGenerativeAI(
    model="gemini-2.5-flash",
    temperature=0.2
)

### streamlit UI; Set the Page Configuration, Title, and Caption

st.set_page_config(page_title="PDF Chatbot", page_icon=":books:")

st.title("PDF Chatbot :books:")

st.caption("Upload a PDF file and ask questions about its content.")

### Upload PDF file 
# st.file_uploader is a Streamlit widget that allows a user to upload files from
# their local machine through the web interface
uploaded_file = st.file_uploader("Choose a PDF file", type="pdf")

if uploaded_file:
    with st.spinner("Processing PDF..."):
        # Save the uploaded PDF to a temporary file
        # Taking the uploaded PDF from Streamlit and saving it as a temporary file 
        # on your computer so that PyPDFLoader can read it.
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as temp_pdf:
            # Write the uploaded PDF content to the temporary file
            temp_pdf.write(uploaded_file.getbuffer())
            temp_pdf_path = temp_pdf.name

        # Load the PDF using PyPDFLoader
        loader = PyPDFLoader(temp_pdf_path)
        documents = loader.load()

        # Split the documents into chunks
        # RecursiveCharacterTextSplitter is one of the most important components in a RAG 
        # (Retrieval-Augmented Generation) application. Its job is to break a large document 
        # into smaller chunks that can be embedded, stored in the vector database, and later
        # retrieved efficiently
        # Each chunk will contain approximately 1000 characters.
        # To preserve context, 200 characters from the previous chunk are repeated in the next chunk
        text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
        docs = text_splitter.split_documents(documents)

        # Try to print the output of the first chunk
        #print(docs[0].page_content)
        
        st.success("PDF processed successfully!")

        # Embeddings are numerical representations of text. Create embeddings using HuggingFaceEmbeddings
        embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")

        # Create a Chroma vector store
        vectorstore = Chroma.from_documents(
            documents=docs, 
            embedding=embeddings,
            collection_name="pdf_collection"
            )
    
        ##MMR retriever
        ## converts your Chroma vector store into a retriever that can be used by a RAG application to
        #  fetch the most relevant document chunks for a user's question.
        retriever = vectorstore.as_retriever(
            search_type="mmr",
            search_kwargs={
                "k": 4,
                "fetch_k": 20
            }
        )

        #### Add prompt template
        prompt_template = """
           You are an expert document analyst.

           Answer the user's question using ONLY the information from the document context.

           Instructions:
          - Be accurate and factual.
          - Provide detailed explanations.
          - Organize answers using headings and bullet points.
          - Highlight important dates, names, numbers, and findings.
          - If the answer is partially available, clearly mention what is available.
          - If the answer is not present, state that explicitly.
          - Never hallucinate information.

           Context:
           {context}

           Question:
           {question}

           Answer:
        """

        PROMPT = PromptTemplate(
            template=prompt_template,
            input_variables=["context", "question"]
        )

        #### calling RAG framework

###        qa_chain = RetrievalQA.from_chain_type(
###         llm=llm,
###         retriever=retriever
###     )

        qa_chain = RetrievalQA.from_chain_type(
        llm=llm,
        retriever=retriever,
        chain_type="stuff",
        chain_type_kwargs={
        "prompt": PROMPT
        },
    return_source_documents=True
)

    ### UI to ask question

query = st.text_input(
    "Ask question about uploaded document"
)

if st.button("Get Anaswer") and query:
    with st.spinner("Generating answer..."):

        try:
            result = qa_chain.invoke(
                {"query": query}
            )
            st.subheader("Answer")
            st.success(result["result"])

        except Exception as e:
            st.error(
                f"Error: {str(e)}"
            )
    
else:
    st.info("Please upload PDF to get started")
