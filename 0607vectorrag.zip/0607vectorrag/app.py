import os
import streamlit as st
from dotenv import load_dotenv
import tempfile

### langchain imports

from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters  import RecursiveCharacterTextSplitter
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_chroma import Chroma
from langchain_classic.chains import RetrievalQA
### load environment variables from .env file

load_dotenv()

GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")

if not GOOGLE_API_KEY:
    st.error("Google API key is not set. Please set it in the .env file.")
    st.stop()

os.environ["GOOGLE_API_KEY"] = GOOGLE_API_KEY

### streamlit UI

st.set_page_config(page_title="PDF Chatbot", page_icon=":books:")

st.title("PDF Chatbot :books:")

st.caption("Upload a PDF file and ask questions about its content.")

### Upload PDF file

uploaded_file = st.file_uploader("Choose a PDF file", type="pdf")

if uploaded_file:
    with st.spinner("Processing PDF..."):
        # Save the uploaded PDF to a temporary file
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as temp_pdf:
            temp_pdf.write(uploaded_file.getbuffer())
            temp_pdf_path = temp_pdf.name

        # Load the PDF using PyPDFLoader
        loader = PyPDFLoader(temp_pdf_path)
        documents = loader.load()

        # Split the documents into chunks
        text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
        docs = text_splitter.split_documents(documents)

        st.success("PDF processed successfully!")

        # Create embeddings using HuggingFaceEmbeddings
        embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")

        # Create a Chroma vector store
        vectorstore = Chroma.from_documents(
            documents=docs, 
            embedding=embeddings,
            collection_name="pdf_collection"
            )
        
        ##MMR retriever

        retriever = vectorstore.as_retriever(
            search_type="mmr",
            search_kwargs={
                "k": 4,
                "fetch_k": 20
            }
        )


        ### LLM

        llm = ChatGoogleGenerativeAI(
            model="gemini-2.5-flash",
            temperature=0.2
        )

        #### calling RAG framework

        qa_chain = RetrievalQA.from_chain_type(
            llm=llm,
            retriever=retriever
        )

    ### UI to ask question

query = st.text_input(
    "Ask question about uploaded document"
)

if st.button("Get Anaswer") and query:
    with st.spinner("Generating answer..."):

        try:
            result = qa_chain.invoke(
                {"query": query}
            )
            st.subheader("Answer")
            st.success(result["result"])

        except Exception as e:
            st.error(
                f"Error: {str(e)}"
            )
    
else:
    st.info("Please upload PDF to get started")
