from re import VERBOSE
### AI agent using litellm and crew framework

### install packages

#!pip install -q crewai crewai-tools litellm

#print("Installation Complete")


#### single agent example

import litellm

litellm.drop_params = True

from crewai import Agent, Task, Crew, LLM
import os
import time
from getpass import getpass

#### Get GROQ API key

print("Enter GROQ API key")
print("Get one free at https://console.groq.com/keys")
groq_api_key = getpass("GROQ API Key: ")

### set environment variable

os.environ["GROQ_API_KEY"] = groq_api_key

### initialize LLM

llm = LLM(
    model="groq/llama-3.1-8b-instant",
    temperature=0.6,
    max_tokens=1000,
    api_key=groq_api_key,
    #is_litellm=True

)

print("LLM Initialized")

### create a simple resarch agent

resarcher = Agent(
    role="Resarch Analyst",
    goal="Resarch topics and provide clear, concise outputs",
    backstory="You are a skilled resarcher who provides accurate information.",
    verbose=True,
    llm=llm 

)

#### create a simple task

research_task = Task(
    description=""" Research the topic: {topic}
Provide a bried overview in 3-4 lines.
Focus on the most important points of the resarch.""",
    agent=resarcher,
    expected_output=" A concise, bulleted point based overview of topic in 3.4 lines" 
)


### create a crew with agent

crew = Crew(
    agent=[resarcher],
    tasks=[research_task],
    verbose=True


)


#### execute the task

print("\n Starting Resarch.....")
print("=" * 50)

result = crew.kickoff(
    inputs={
        "topic": "The future of AI"
    }
)


print("\n" + "=" * 50)
print("Resarch Complete")
print(result)
print("=" * 50)